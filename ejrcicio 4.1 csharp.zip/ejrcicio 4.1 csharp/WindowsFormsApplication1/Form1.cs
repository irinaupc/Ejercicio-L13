﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
           
            IPAddress direc = IPAddress.Parse("192.168.1.38");
            IPEndPoint ipep = new IPEndPoint(direc, 9050);
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);
                this.BackColor = Color.LightGreen;
                MessageBox.Show("Conectado");

            }
            catch (SocketException)
            { 
                MessageBox.Show("No se pudo conectar con el servidor");
                return;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Longitud.Checked)
                // Consulta longitud nombre
            {
                string mensaje = "1/" + nombre.Text;
                //Envio
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Respuesta
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split ('\0')[0];
                MessageBox.Show("Tu nombre tiene longitud de : " + mensaje + "caracteres");
            }
            else if (Bonito.Checked)  
                // Consulta de si el nombre es bonit0
            {
                string mensaje = "2/" + nombre.Text;
                // Envio
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Respuesta
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];


                if (mensaje == "SI")
                    MessageBox.Show("Tu nombre si es bonito.");
                else
                    MessageBox.Show("Tu nombre no es bonito.");

            }
            else if (Palindromo.Checked)
                //consulta Palindromidad
            {
                string mensaje = "4/" + nombre.Text;
                // Envio
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Respuesta
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];


                if (mensaje == "SI")
                    MessageBox.Show("Tu nombre es un palindromo.");
                else
                    MessageBox.Show("Tu nombre no es un palindromo..");
            }
            else
            // consulta de si es alto 
            {
                string mensaje = "3/" + nombre.Text + "/" + alturaBox.Text;
                // Envio
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Respuesta
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                MessageBox.Show(mensaje);
            }
             
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string mensaje = "0/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Bonito_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
